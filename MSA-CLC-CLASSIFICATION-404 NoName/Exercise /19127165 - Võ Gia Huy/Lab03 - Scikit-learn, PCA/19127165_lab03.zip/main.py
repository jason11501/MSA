# importing the libraries
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scipy.stats as stats
import seaborn as sns
from sklearn.preprocessing import scale
from sklearn.decomposition import PCA,FactorAnalysis
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis

#read csv data with pandas
data=pd.read_csv('data/iris.csv')
data.columns=['V'+str(i) for i in range(1,len(data.columns)+1)]
#independent variables data
X=data.loc[:,'V2':'V5']
#dependent  variable data
y=data.V1

print('# Data:')
print(data)

print('# Head:')
print(data.head())

print('# Tail')
print(data.tail())

print('# Info')
print(data.info())

# Plot data for visualization 
pd.plotting.scatter_matrix(data.loc[:,'V2':'V5'],diagonal='kde',figsize=(20,15))
plt.show()

#define data to plot
colors = ['red', 'green', 'blue']
target_names=['iris-sesota','iris-versicolor','iris-virginica']

#Fit the PCA model
pca=PCA()
data1_plot=pca.fit(X.to_numpy()).transform(X.to_numpy())

#create the PCA plot
plt.figure()
for color, i, target_name in zip(colors, [0, 1, 2], target_names):
    plt.scatter(data1_plot[y == i, 0], data1_plot[y == i, 1], color=color, alpha=0.8, lw=2, label=target_name)

#add legend to plot
plt.legend(loc='best', shadow=False, scatterpoints=1)

#Title of graph
plt.xlabel("Principle component 1")
plt.ylabel('Principle component 2')
plt.title('PCA')

#Fit the LDA model 
lda = LinearDiscriminantAnalysis()
data2_plot = lda.fit(X.to_numpy(), y.to_numpy()).transform(X.to_numpy())

#create LDA plot
plt.figure()
for color, i, target_name in zip(colors, [0, 1, 2], target_names):
    plt.scatter(data2_plot[y == i, 0], data2_plot[y == i, 1], alpha=0.8,lw=2, color=color,
                label=target_name)

#add legend to plot
plt.legend(loc='best', shadow=False, scatterpoints=1)

#Title of graph
plt.title('LDA')

# Fit factor analysis model 
fa=FactorAnalysis()
data3_plot=fa.fit_transform(X.to_numpy())

#create LDA plot
plt.figure()
for color, i, target_name in zip(colors, [0, 1, 2], target_names):
    plt.scatter(data3_plot[y == i, 0], data3_plot[y == i, 1], alpha=0.8,lw=2, color=color,
                label=target_name)

#add legend to plot
plt.legend(loc='best', shadow=False, scatterpoints=1)

#Title of graph
plt.title('Factor analysis')
plt.xlabel('Factor 1')
plt.ylabel('Factor 2')
#display all plot
plt.show()


