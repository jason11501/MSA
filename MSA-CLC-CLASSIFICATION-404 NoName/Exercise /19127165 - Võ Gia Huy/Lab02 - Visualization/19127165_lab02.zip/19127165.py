import pandas as pd
import matplotlib.pyplot as plt

# read csv file and load to data frame
df = pd.read_csv('data/covid-19-cases.csv')
# use seaborn stylesheet
plt.style.use("seaborn")
# get dataframe for provinces/states in Australia
df_aus=df.loc[df['Country/Region']=='Australia']
n=len(df_aus)
# create array for value in collumn Province/State
province_state_arr=df_aus['Province/State'].to_numpy()
print(province_state_arr)
# create array for last collumn
case_arr=df_aus[df_aus.columns[-1]].to_numpy()
print(case_arr)
# create color array for pie graph
color_arr=['k','g','b','c','m','hotpink','y','r']
# plot pie graph
plt.pie(case_arr,labels=province_state_arr,colors=color_arr)
# set position of legend in pie chart
plt.legend(loc='lower right')
plt.title('RATIO OF CASES IN PROVINCES/STATES OF AUSTRALIA NOW')
plt.savefig('1.png')
plt.show()


# plot bar graph
# change fontsize of label
plt.xticks(fontsize=5)
plt.bar(province_state_arr,case_arr)
plt.title('AMOUNT OF CASES IN PROVINCES/STATES OF AUSTRALIA NOW')
plt.savefig('2.png')
plt.show()


# group by country column and sum over the different states/regions of each country
group=df.groupby('Country/Region')
df_country=group.sum()
# create dataframe of top 5 country with most case
top5_country=df_country.nlargest(5,df_country.columns[-1])
# plot barh graph
# change fontsize of label
plt.yticks(fontsize=10)
country_arr=top5_country.index.to_numpy()
total_case_arr=top5_country[top5_country.columns[-1]].to_numpy()
plt.barh(country_arr,total_case_arr)
plt.title('TOP 5 COUNTRIES WHICH HAVE MOST CASES NOW')
plt.savefig('3.png')
plt.show()










