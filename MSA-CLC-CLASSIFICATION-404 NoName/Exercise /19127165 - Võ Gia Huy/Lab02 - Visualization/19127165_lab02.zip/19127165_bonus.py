import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# read csv file and load to data frame
df=pd.read_csv('data_bonus/country wise-so2-emissions-per-capita_1850-2000.csv')
# use seaborn stylesheet
plt.style.use("seaborn")
# create data frame of top 3 country which have highest gdp in 2020
df_country_2000=df.loc[df['Year']==2000]
# group by entity column
group=df_country_2000.groupby('Entity')
df_country=group.sum()
# create data frame of top 5 country which have highest SO2 emission per capita  in 2020
top5_country=df_country.nlargest(5, df_country.columns[-1])

# plot barh graph with mathplptlib
# change fontsize of label
plt.yticks(fontsize=10)
country_arr=top5_country.index.to_numpy()
gdp_arr=top5_country[top5_country.columns[-1]].to_numpy()
plt.bar(country_arr,gdp_arr)
plt.title('TOP 5 COUNTRIES WHICH HAVE HEIGHEST SO2 PERMISSION PER CAPITA IN 2000')
plt.savefig('4.png')
plt.show()

# plot barh graph with seaborn
sns.barplot(country_arr,gdp_arr)
plt.title('TOP 5 COUNTRIES WHICH HAVE HEIGHEST SO2 PERMISSION PER CAPITA IN 2000')
plt.savefig('5.png')
plt.show()




